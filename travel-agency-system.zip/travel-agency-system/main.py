from ui.main_window import MainWindow
import tkinter as tk

if __name__ == "__main__":
    root = MainWindow()
    root.mainloop()
